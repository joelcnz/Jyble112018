Bible Gate
----------

This program was made with the "D Programming Language" - www.digitalmars.com/d

Win version using DFL
www.dprogramming.com


Any questions one can e-mail Joel (the programmer).  joelcnz@gmail.com