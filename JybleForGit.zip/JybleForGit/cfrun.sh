./cf.sh
./run.sh
